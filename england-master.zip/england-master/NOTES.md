# Notes

## Premier League

Official site - [`www.premierleague.com`](http://www.premierleague.com)

- 20 teams
- 380 matches

### Wikipedia

- [Premier_League](http://en.wikipedia.org/wiki/Premier_League)
- [2013–14_Premier_League](http://en.wikipedia.org/wiki/2013–14_Premier_League)
- [2012–13_Premier_League](http://en.wikipedia.org/wiki/2012–13_Premier_League)

### Ups / Downs

2015/16:
- (++)  Bournemouth, Watford, Norwich City
- (--)  Hull, Burnley, Queens Park Rangers

2014/15:
- (++)  Leicester City, Burnley, Queens Park Rangers
- (--)  Cardiff City, Fulham, Norwich City

Championship

2015/16:
- ++ (from League One) Bristol City, Milton Keynes Dons, Preston North End 
- ++ (from Premier League) Hull City, Burnley, Queens Park Rangers
-  -- (to League One) Millwall, Wigan Athletic, Blackpool
-  -- (to Premier League) Bournemouth, Watford, Norwich City
