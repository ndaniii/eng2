

### Standings

#### Premier League


```
                                        - Total -                  - Home -          - Away -     
                                 Pld   W  D  L   F:A   +/-  Pts   W  D  L   F:A     W  D  L   F:A
 1. Chelsea FC                    38  30  3  5  85:33  +52   93  17  0  2  55:17   13  3  3  30:16 
 2. Tottenham Hotspur FC          38  26  8  4  86:26  +60   86  17  2  0  47:9     9  6  4  39:17 
 3. Manchester City FC            38  23  9  6  80:39  +41   78  11  7  1  37:17   12  2  5  43:22 
 4. Liverpool FC                  38  22 10  6  78:42  +36   76  12  5  2  45:18   10  5  4  33:24 
 5. Arsenal FC                    38  23  6  9  77:44  +33   75  14  3  2  39:16    9  3  7  38:28 
 6. Manchester United FC          38  18 15  5  54:29  +25   69   8 10  1  26:12   10  5  4  28:17 
 7. Everton FC                    38  17 10 11  62:44  +18   61  13  4  2  42:16    4  6  9  20:28 
 8. Southampton FC                38  12 10 16  41:48   -7   46   6  6  7  17:21    6  4  9  24:27 
 9. AFC Bournemouth               38  12 10 16  55:67  -12   46   9  4  6  35:29    3  6 10  20:38 
10. West Bromwich Albion FC       38  12  9 17  43:51   -8   45   9  2  8  27:22    3  7  9  16:29 
11. West Ham United FC            38  12  9 17  47:64  -17   45   7  4  8  19:31    5  5  9  28:33 
12. Leicester City FC             38  12  8 18  48:63  -15   44  10  4  5  31:25    2  4 13  17:38 
13. Stoke City FC                 38  11 11 16  41:56  -15   44   7  6  6  24:24    4  5 10  17:32 
14. Crystal Palace FC             38  12  5 21  50:63  -13   41   6  2 11  24:25    6  3 10  26:38 
15. Swansea City FC               38  12  5 21  45:70  -25   41   8  3  8  27:34    4  2 13  18:36 
16. Burnley FC                    38  11  7 20  39:55  -16   40  10  3  6  26:20    1  4 14  13:35 
17. Watford FC                    38  11  7 20  40:68  -28   40   8  4  7  25:29    3  3 13  15:39 
18. Hull City AFC                 38   9  7 22  37:80  -43   34   8  4  7  28:35    1  3 15   9:45 
19. Middlesbrough FC              38   5 13 20  27:53  -26   28   4  6  9  17:23    1  7 11  10:30 
20. Sunderland AFC                38   6  6 26  29:69  -40   24   3  5 11  16:34    3  1 15  13:35 
```




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

