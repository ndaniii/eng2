

### Standings

#### Premier League


```
                                        - Total -                  - Home -          - Away -     
                                 Pld   W  D  L   F:A   +/-  Pts   W  D  L   F:A     W  D  L   F:A
 1. Manchester City FC            38  27  5  6 102:37  +65   86  17  1  1  63:13   10  4  5  39:24 
 2. Liverpool FC                  38  26  6  6 101:50  +51   84  16  1  2  53:18   10  5  4  48:32 
 3. Chelsea FC                    38  25  7  6  71:27  +44   82  15  3  1  43:11   10  4  5  28:16 
 4. Arsenal FC                    38  24  7  7  68:41  +27   79  13  5  1  36:11   11  2  6  32:30 
 5. Everton FC                    38  21  9  8  61:39  +22   72  13  3  3  38:19    8  6  5  23:20 
 6. Tottenham Hotspur FC          38  21  6 11  55:51   +4   69  11  3  5  30:23   10  3  6  25:28 
 7. Manchester United FC          38  19  7 12  64:43  +21   64   9  3  7  29:21   10  4  5  35:22 
 8. Southampton FC                38  15 11 12  54:46   +8   56   8  6  5  32:23    7  5  7  22:23 
 9. Stoke City FC                 38  13 11 14  45:52   -7   50  10  6  3  27:17    3  5 11  18:35 
10. Newcastle United FC           38  15  4 19  43:59  -16   49   8  3  8  23:28    7  1 11  20:31 
11. Crystal Palace FC             38  13  6 19  33:48  -15   45   8  3  8  18:23    5  3 11  15:25 
12. Swansea City FC               38  11  9 18  54:54        42   6  5  8  33:26    5  4 10  21:28 
13. West Ham United FC            38  11  7 20  40:51  -11   40   7  3  9  25:26    4  4 11  15:25 
14. Sunderland AFC                38  10  8 20  41:60  -19   38   5  3 11  21:27    5  5  9  20:33 
15. Aston Villa FC                38  10  8 20  39:61  -22   38   6  3 10  22:29    4  5 10  17:32 
16. Hull City AFC                 38  10  7 21  38:53  -15   37   7  4  8  20:21    3  3 13  18:32 
17. West Bromwich Albion FC       38   7 15 16  43:59  -16   36   4  9  6  24:27    3  6 10  19:32 
18. Norwich City FC               38   8  9 21  28:62  -34   33   6  6  7  17:18    2  3 14  11:44 
19. Fulham FC                     38   9  5 24  40:85  -45   32   5  3 11  24:38    4  2 13  16:47 
20. Cardiff City FC               38   7  9 22  32:74  -42   30   5  5  9  20:35    2  4 13  12:39 
```




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

