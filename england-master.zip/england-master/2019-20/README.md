

### Standings

#### Premier League


```
                                        - Total -                  - Home -          - Away -     
                                 Pld   W  D  L   F:A   +/-  Pts   W  D  L   F:A     W  D  L   F:A
 1. Liverpool FC                  29  27  1  1  66:21  +45   82  15  0  0  40:12   12  1  1  26:9  
 2. Manchester City FC            28  18  3  7  68:31  +37   57   9  2  2  33:12    9  1  5  35:19 
 3. Leicester City FC             29  16  5  8  58:28  +30   53   9  3  3  30:15    7  2  5  28:13 
 4. Chelsea FC                    29  14  6  9  51:39  +12   48   7  3  5  22:15    7  3  4  29:24 
 5. Manchester United FC          29  12  9  8  44:30  +14   45   8  5  2  29:12    4  4  6  15:18 
 6. Wolverhampton Wanderers FC    29  10 13  6  41:34   +7   43   5  7  3  21:17    5  6  3  20:17 
 7. Sheffield United FC           28  11 10  7  30:25   +5   43   7  3  5  17:13    4  7  2  13:12 
 8. Tottenham Hotspur FC          29  11  8 10  47:40   +7   41   8  2  4  27:15    3  6  6  20:25 
 9. Arsenal FC                    28   9 13  6  40:36   +4   40   7  5  3  26:20    2  8  3  14:16 
10. Burnley FC                    29  11  6 12  34:40   -6   39   7  2  6  20:19    4  4  6  14:21 
11. Crystal Palace FC             29  10  9 10  26:32   -6   39   6  4  5  12:13    4  5  5  14:19 
12. Everton FC                    29  10  7 12  37:46   -9   37   7  4  3  19:15    3  3  9  18:31 
13. Newcastle United FC           29   9  8 12  25:41  -16   35   5  6  3  12:12    4  2  9  13:29 
14. Southampton FC                29  10  4 15  35:52  -17   34   4  2  9  16:31    6  2  6  19:21 
15. Brighton & Hove Albion FC     29   6 11 12  31:39   -8   29   4  6  4  17:15    2  5  8  14:24 
16. West Ham United FC            29   7  6 16  35:50  -15   27   4  3  7  23:26    3  3  9  12:24 
17. Watford FC                    29   6  9 14  27:44  -17   27   4  5  5  16:17    2  4  9  11:27 
18. AFC Bournemouth               29   7  6 16  29:47  -18   27   4  5  5  17:21    3  1 11  12:26 
19. Aston Villa FC                28   7  4 17  33:55  -22   25   5  2  6  17:23    2  2 11  16:32 
20. Norwich City FC               29   5  6 18  25:52  -27   21   4  3  7  19:26    1  3 11   6:26 
```




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

