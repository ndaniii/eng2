# Notes


```
# Aufsteiger Premier League
#
# AFC Bournemouth
# Watford FC
# Norwich City
#
# Play Off Spiele Premiere League
#
# Brentford FC     1-2 Middlesbrough FC
# Middlesbrough FC 3-0 Brentford FC
#
# Ipswich Town     1-1 Norwich City
# Norwich City     3-1 Ipswich Town
#
# Norwich City     2-0 Middlesbrough FC
```
