

### Standings

#### Premier League


```
                                        - Total -                  - Home -          - Away -     
                                 Pld   W  D  L   F:A   +/-  Pts   W  D  L   F:A     W  D  L   F:A
 1. Chelsea FC                    38  26  9  3  73:32  +41   87  15  4  0  36:9    11  5  3  37:23 
 2. Manchester City FC            38  24  7  7  83:38  +45   79  14  3  2  44:14   10  4  5  39:24 
 3. Arsenal FC                    38  22  9  7  71:36  +35   75  12  5  2  41:14   10  4  5  30:22 
 4. Manchester United FC          38  20 10  8  62:37  +25   70  14  2  3  41:15    6  8  5  21:22 
 5. Tottenham Hotspur FC          38  19  7 12  58:53   +5   64  10  3  6  31:24    9  4  6  27:29 
 6. Liverpool FC                  38  18  8 12  52:48   +4   62  10  5  4  30:20    8  3  8  22:28 
 7. Southampton FC                38  18  6 14  54:33  +21   60  11  4  4  37:13    7  2 10  17:20 
 8. Swansea City FC               38  16  8 14  46:49   -3   56   9  5  5  27:22    7  3  9  19:27 
 9. Stoke City FC                 38  15  9 14  48:45   +3   54  10  3  6  32:22    5  6  8  16:23 
10. Crystal Palace FC             38  13  9 16  47:51   -4   48   6  3 10  21:27    7  6  6  26:24 
11. Everton FC                    38  12 11 15  48:50   -2   47   7  7  5  27:21    5  4 10  21:29 
12. West Ham United FC            38  12 11 15  44:47   -3   47   9  4  6  25:18    3  7  9  19:29 
13. West Bromwich Albion FC       38  11 11 16  38:51  -13   44   7  4  8  24:26    4  7  8  14:25 
14. Leicester City FC             38  11  8 19  46:55   -9   41   7  5  7  28:22    4  3 12  18:33 
15. Newcastle United FC           38  10  9 19  40:63  -23   39   7  5  7  26:27    3  4 12  14:36 
16. Sunderland AFC                38   7 17 14  31:53  -22   38   4  8  7  16:27    3  9  7  15:26 
17. Aston Villa FC                38  10  8 20  31:57  -26   38   5  6  8  18:25    5  2 12  13:32 
18. Hull City AFC                 38   8 11 19  33:51  -18   35   5  5  9  19:24    3  6 10  14:27 
19. Burnley FC                    38   7 12 19  28:53  -25   33   4  7  8  14:21    3  5 11  14:32 
20. Queens Park Rangers FC        38   8  6 24  42:73  -31   30   6  5  8  23:24    2  1 16  19:49 
```




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

