

### Standings

#### Premier League


```
                                        - Total -                  - Home -          - Away -     
                                 Pld   W  D  L   F:A   +/-  Pts   W  D  L   F:A     W  D  L   F:A
 1. Manchester City FC            38  32  2  4  95:23  +72   98  18  0  1  57:12   14  2  3  38:11 
 2. Liverpool FC                  38  30  7  1  89:22  +67   97  17  2  0  55:10   13  5  1  34:12 
 3. Chelsea FC                    38  21  9  8  63:39  +24   72  12  6  1  39:12    9  3  7  24:27 
 4. Tottenham Hotspur FC          38  23  2 13  67:39  +28   71  12  2  5  34:16   11  0  8  33:23 
 5. Arsenal FC                    38  21  7 10  73:51  +22   70  14  3  2  42:16    7  4  8  31:35 
 6. Manchester United FC          38  19  9 10  65:54  +11   66  10  6  3  33:25    9  3  7  32:29 
 7. Wolverhampton Wanderers FC    38  16  9 13  47:46   +1   57  10  4  5  28:21    6  5  8  19:25 
 8. Everton FC                    38  15  9 14  54:46   +8   54  10  4  5  30:21    5  5  9  24:25 
 9. Leicester City FC             38  15  7 16  51:48   +3   52   8  3  8  24:20    7  4  8  27:28 
10. West Ham United FC            38  15  7 16  52:55   -3   52   9  4  6  32:27    6  3 10  20:28 
11. Watford FC                    38  14  8 16  52:59   -7   50   8  3  8  26:28    6  5  8  26:31 
12. Crystal Palace FC             38  14  7 17  51:53   -2   49   5  5  9  19:23    9  2  8  32:30 
13. Newcastle United FC           38  12  9 17  42:48   -6   45   8  1 10  24:25    4  8  7  18:23 
14. AFC Bournemouth               38  13  6 19  56:70  -14   45   8  5  6  30:25    5  1 13  26:45 
15. Burnley FC                    38  11  7 20  45:68  -23   40   7  2 10  24:32    4  5 10  21:36 
16. Southampton FC                38   9 12 17  45:65  -20   39   5  8  6  27:30    4  4 11  18:35 
17. Brighton & Hove Albion FC     38   9  9 20  35:60  -25   36   6  5  8  19:28    3  4 12  16:32 
18. Cardiff City FC               38  10  4 24  34:69  -35   34   6  2 11  21:38    4  2 13  13:31 
19. Fulham FC                     38   7  5 26  34:81  -47   26   6  3 10  22:36    1  2 16  12:45 
20. Huddersfield Town AFC         38   3  7 28  22:76  -54   16   2  3 14  10:31    1  4 14  12:45 
```




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

