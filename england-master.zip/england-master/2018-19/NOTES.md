# Notes

Premier League

```
# 3 Absteiger Premier League 2018/19:
# Huddersfield Town
# Fulham FC
# Cardiff City or Brighton & Hove Albion

# 3 Aufsteiger to Premier League 2019/20:
#  Norwich City
#  Sheffield United
#  Either Leeds United, West Bromwich Albion, Aston Villa or Derby County, Middlesbrough FC, Bristol City.


# 3. Absteiger Premier League 2018/19:
#  Cardiff City

# Meister Premier League 2018/19:
#  Manchester City


# todo: add relegation playoff !!!


# 3. Aufsteiger to Premier League 2019/20:
# Halbfinale:
[Sat May/11]
  Aston Villa             2-1 West Bromwich Albions
  Derby County            0-1 Leeds United
[Tue May/14]
  West Bromwich Albions   1-0 Aston Villa   3-4 after penalty
[Wed May/15]
  Leeds United            2-4 Derby County

# Finale:
[Mon May/27]
  Derby Country           1-2 Aston Villa

# Play-off Winner to Premier League 2019/20:
#  Aston Villa


# Finish Premier League 2018/19

# 9.8. Start Premier League 2019/20
```


