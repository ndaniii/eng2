

### Standings

#### Premier League


```
                                        - Total -                  - Home -          - Away -     
                                 Pld   W  D  L   F:A   +/-  Pts   W  D  L   F:A     W  D  L   F:A
 1. Leicester City FC             38  23 12  3  68:36  +32   81  12  6  1  35:18   11  6  2  33:18 
 2. Arsenal FC                    38  20 11  7  65:36  +29   71  12  4  3  31:11    8  7  4  34:25 
 3. Tottenham Hotspur FC          38  19 13  6  69:35  +34   70  10  6  3  35:15    9  7  3  34:20 
 4. Manchester City FC            38  19  9 10  71:41  +30   66  12  2  5  47:21    7  7  5  24:20 
 5. Manchester United FC          38  19  9 10  49:35  +14   66  12  5  2  27:9     7  4  8  22:26 
 6. Southampton FC                38  18  9 11  59:41  +18   63  11  3  5  39:22    7  6  6  20:19 
 7. West Ham United FC            38  16 14  8  65:51  +14   62   9  7  3  34:26    7  7  5  31:25 
 8. Liverpool FC                  38  16 12 10  63:50  +13   60   8  8  3  33:22    8  4  7  30:28 
 9. Stoke City FC                 38  14  9 15  41:55  -14   51   8  4  7  22:24    6  5  8  19:31 
10. Chelsea FC                    38  12 14 12  59:53   +6   50   5  9  5  32:30    7  5  7  27:23 
11. Everton FC                    38  11 14 13  59:55   +4   47   6  5  8  35:30    5  9  5  24:25 
12. Swansea City FC               38  12 11 15  42:52  -10   47   8  6  5  20:20    4  5 10  22:32 
13. Watford FC                    38  12  9 17  40:50  -10   45   6  6  7  20:19    6  3 10  20:31 
14. West Bromwich Albion FC       38  10 13 15  34:48  -14   43   6  5  8  20:26    4  8  7  14:22 
15. Crystal Palace FC             38  11  9 18  39:51  -12   42   6  3 10  19:23    5  6  8  20:28 
16. AFC Bournemouth               38  11  9 18  45:67  -22   42   5  5  9  23:34    6  4  9  22:33 
17. Sunderland AFC                38   9 12 17  48:62  -14   39   6  6  7  23:20    3  6 10  25:42 
18. Newcastle United FC           38   9 10 19  44:65  -21   37   7  7  5  32:24    2  3 14  12:41 
19. Norwich City FC               38   9  7 22  39:67  -28   34   6  5  8  26:30    3  2 14  13:37 
20. Aston Villa FC                38   3  8 27  27:76  -49   17   2  5 12  14:35    1  3 15  13:41 
```




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

