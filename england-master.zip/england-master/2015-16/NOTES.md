# Notes


```
# Leicester erstmals englischer Fussballmeister!
#
# Absteiger  Premiere League: Aston Villa, Newcastle United, Norwich City.
# Aufsteiger in Premiere League: Burnley, FC Middlesborough, 1 Platz noch offen.

## todo/fix: add relegation playoff

# Play-Off um 1 Premierleague-Platz:

13.5.16  Sheffield Wednesday  2-0 Brighton&Hove Albion
16.5.16  Brighton&Hove Albion 1-1 Sheffield Wednesday

14.5.16  Derby Country        0-3 Hull City
17.5.16  Hull City            0-2 Derby Country


28.5.16  Hull City 1-0 Sheffield Wednesday

# 3. Aufsteiger in Premierleague:
#
# Hull City.
```
