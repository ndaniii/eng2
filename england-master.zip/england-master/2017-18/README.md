

### Standings

#### Premier League


```
                                        - Total -                  - Home -          - Away -     
                                 Pld   W  D  L   F:A   +/-  Pts   W  D  L   F:A     W  D  L   F:A
 1. Manchester City FC            38  32  4  2 106:27  +79  100  16  2  1  61:14   16  2  1  45:13 
 2. Manchester United FC          38  25  6  7  68:28  +40   81  15  2  2  38:9    10  4  5  30:19 
 3. Tottenham Hotspur FC          38  23  8  7  74:36  +38   77  13  4  2  40:16   10  4  5  34:20 
 4. Liverpool FC                  38  21 12  5  84:38  +46   75  12  7  0  45:10    9  5  5  39:28 
 5. Chelsea FC                    38  21  7 10  62:38  +24   70  11  4  4  30:16   10  3  6  32:22 
 6. Arsenal FC                    38  19  6 13  74:51  +23   63  15  2  2  54:20    4  4 11  20:31 
 7. Burnley FC                    38  14 12 12  36:39   -3   54   7  5  7  16:17    7  7  5  20:22 
 8. Everton FC                    38  13 10 15  44:58  -14   49  10  4  5  28:22    3  6 10  16:36 
 9. Leicester City FC             38  12 11 15  56:60   -4   47   7  6  6  25:22    5  5  9  31:38 
10. Newcastle United FC           38  12  8 18  39:47   -8   44   8  4  7  21:17    4  4 11  18:30 
11. Crystal Palace FC             38  11 11 16  45:55  -10   44   7  5  7  29:27    4  6  9  16:28 
12. AFC Bournemouth               38  11 11 16  45:61  -16   44   7  5  7  26:30    4  6  9  19:31 
13. West Ham United FC            38  10 12 16  48:68  -20   42   7  6  6  24:26    3  6 10  24:42 
14. Watford FC                    38  11  8 19  44:64  -20   41   7  6  6  27:31    4  2 13  17:33 
15. Brighton & Hove Albion FC     38   9 13 16  34:54  -20   40   7  8  4  24:25    2  5 12  10:29 
16. Huddersfield Town AFC         38   9 10 19  28:58  -30   37   6  5  8  16:25    3  5 11  12:33 
17. Southampton FC                38   7 15 16  37:56  -19   36   4  7  8  20:26    3  8  8  17:30 
18. Swansea City FC               38   8  9 21  28:56  -28   33   6  3 10  17:24    2  6 11  11:32 
19. Stoke City FC                 38   7 12 19  35:68  -33   33   5  5  9  20:30    2  7 10  15:38 
20. West Bromwich Albion FC       38   6 13 19  31:56  -25   31   3  9  7  21:29    3  4 12  10:27 
```




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

