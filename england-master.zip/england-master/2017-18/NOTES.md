# Notes

## Premier League

```
# proposed 1. Aufsteiger in PremierLeague 2018/19:
# Wolverhampton Wanderers

# 1. PremierLeague Aufsteiger 2018/19:
#  Wolverhampton Wanderers
#
# Master PremierLeague 2017/18:
#  Manchester City

# 2. Aufsteiger PremierLeague 2018/19:
#   Cardiff City

# 2. Absteiger PremierLeague 2017/18:
#   West Bromwich Albion

##  winner for play-off final 2017/18 qualified:
# [Fri May/11]
#  Derby County               1-0  FC Fulham
# [Sat May/12]
#  FC Middlesbrough           0-1  Aston Villa
# [Mon May/14]
#  FC Fulham                  2-0  Derby County
# [Tue May/15]
#  Aston Villa                0-0  FC Middlesbrough

# 3. Absteiger PremierLeague 2017/18:
#    Swansea City

# winner to PremierLeague 2018/19:
#  [Sat May/26]
#    FC Fulham               1-0 Aston Villa
#
# 3. Aufsteiger PremiereLeague 2018/19:
#    FC Fulham
```