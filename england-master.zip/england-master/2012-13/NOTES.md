# Notes

```
Matchday 2

### nota 2 - 11.12 19.45  *** delayed
#
#  El partido entre Sunderland y Reading (programado para el 25 de agosto de 2012 a las 15.00)
# fue suspendido debido a que el terreno de juego no estaba en buenas condiciones
# por las lluvias en el noroeste de Inglaterra.
## todo: check status of this game why set to 0:0 and  ??


Matchday 3

### note 3
# El partido entre Chelsea y Reading se jugó antes de la segunda jornada debido
# a que el Chelsea estará disputando la Supercopa de Europa 2012 el 31 de agosto de 2012.
## set to different date - ?


Matchday 17

## nota 4
# El partido entre Chelsea y Southampton (jornada 17) fue aplazado debido
# a la participación del Chelsea en la Copa Mundial de Clubes de la FIFA 2012.
# Se iba a disputar el 15 de diciembre de 2012.

Matchday 19

## nota 5
# El partido entre Arsenal y West Ham se aplazó por la huelga en el metro de Londres.
# Se iba a disputar en la misma fecha del Boxing Day, el 26 de diciembre de 2012.
### nota 5 - date changed to 23.01.2013 19.45  ??
```