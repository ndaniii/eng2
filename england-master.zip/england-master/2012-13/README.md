

### Standings

#### Premier League


```
                                        - Total -                  - Home -          - Away -     
                                 Pld   W  D  L   F:A   +/-  Pts   W  D  L   F:A     W  D  L   F:A
 1. Manchester United FC          38  28  5  5  86:43  +43   89  16  0  3  45:19   12  5  2  41:24 
 2. Manchester City FC            38  23  9  6  66:34  +32   78  14  3  2  41:15    9  6  4  25:19 
 3. Chelsea FC                    38  22  9  7  75:39  +36   75  12  5  2  41:16   10  4  5  34:23 
 4. Arsenal FC                    38  21 10  7  72:37  +35   73  11  5  3  47:23   10  5  4  25:14 
 5. Tottenham Hotspur FC          38  21  9  8  66:46  +20   72  11  5  3  29:18   10  4  5  37:28 
 6. Everton FC                    38  16 15  7  55:40  +15   63  12  6  1  33:17    4  9  6  22:23 
 7. Liverpool FC                  38  16 13  9  71:43  +28   61   9  6  4  33:16    7  7  5  38:27 
 8. West Bromwich Albion FC       38  14  7 17  53:57   -4   49   9  4  6  32:25    5  3 11  21:32 
 9. Swansea City FC               38  11 13 14  47:51   -4   46   6  8  5  28:26    5  5  9  19:25 
10. West Ham United FC            38  12 10 16  45:53   -8   46   9  6  4  34:22    3  4 12  11:31 
11. Norwich City FC               38  10 14 14  41:58  -17   44   8  7  4  25:20    2  7 10  16:38 
12. Fulham FC                     38  11 10 17  50:60  -10   43   7  3  9  28:30    4  7  8  22:30 
13. Stoke City FC                 38   9 15 14  34:45  -11   42   7  7  5  21:22    2  8  9  13:23 
14. Southampton FC                38   9 14 15  49:60  -11   41   6  7  6  26:24    3  7  9  23:36 
15. Aston Villa FC                38  10 11 17  47:69  -22   41   5  5  9  23:28    5  6  8  24:41 
16. Newcastle United FC           38  11  8 19  45:68  -23   41   9  1  9  24:31    2  7 10  21:37 
17. Sunderland AFC                38   9 12 17  41:54  -13   39   5  8  6  20:19    4  4 11  21:35 
18. Wigan Athletic FC             38   9  9 20  47:73  -26   36   4  6  9  26:39    5  3 11  21:34 
19. Reading FC                    38   6 10 22  43:73  -30   28   4  8  7  23:33    2  2 15  20:40 
20. Queens Park Rangers FC        38   4 13 21  30:60  -30   25   2  8  9  13:28    2  5 12  17:32 
```




---
Pld = Matches; W = Matches won; D = Matches drawn; L = Matches lost; F = Goals for; A = Goals against; +/- = Goal differencence; Pts = Points

