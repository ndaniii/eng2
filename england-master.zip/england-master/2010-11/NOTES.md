# Notes

## English Premier League 2010/11

- see <http://en.wikipedia.org/wiki/2010–11_Premier_League>

## English Championship 2010/11 + Play-offs

- see <https://en.wikipedia.org/wiki/2011_Football_League_play-offs#Championship>
